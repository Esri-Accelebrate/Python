#!/usr/bin/env python

def ham(n):
    return n * 10

